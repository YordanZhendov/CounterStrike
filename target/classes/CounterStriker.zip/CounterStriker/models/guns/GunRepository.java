package CounterStriker.models.guns;

import CounterStriker.repositories.Repository;

import java.util.Collection;

import static CounterStriker.common.ExceptionMessages.INVALID_GUN_REPOSITORY;

public class GunRepository implements Repository {

    private Collection<Gun> guns;


    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {
        if(model==null){
            throw new NullPointerException(INVALID_GUN_REPOSITORY);
        }
        guns.add((Gun) model);
    }

    @Override
    public boolean remove(Object model) {
        return guns.remove((Gun) model);
    }

    public Gun findByName(String name){
        for (Gun gun : guns) {
            if(gun.getName().equals(name)){
                return gun;
            }
        }

        return null;

    }
}
