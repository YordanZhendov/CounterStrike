package CounterStriker.models.players;

import CounterStriker.repositories.Repository;

import java.util.Collection;

import static CounterStriker.common.ExceptionMessages.INVALID_PLAYER_REPOSITORY;

public class PlayerRepository implements Repository {
    private Collection<Player> players;

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {
        if(model == null){
            throw new NullPointerException(INVALID_PLAYER_REPOSITORY);
        }
        players.add((Player) model);
    }

    @Override
    public boolean remove(Object model) {
        return this.players.remove((Player) model);
    }

    @Override
    public Object findByName(String name) {

        for (Player player : this.players) {
            if(player.getUsername().equals(name)){
                return player;
            }
        }
        return null;
    }
}
